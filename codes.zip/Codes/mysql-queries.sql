select injury_level, plane_model from aviation_incident where injury_level='Serious' group by injury_level,plane_model;

select injury_level, plane_model from aviation_incident where injury_level=�None� group by injury_level,plane_model;

select aircraft_type, airline_operator,class, count(*) as count from aviation_incident where flight_phase='Landing' group by aircraft_type, airline_operator, class order by count(*) desc;

select aircraft_type,plane_model, injury_level, count(deaths) from aviation_incident where flight_phase='Landing' group by aircraft_type,plane_model,injury_level order by count(deaths) desc;


select aircraft_type,plane_model, injury_level, count(deaths) from aviation_incident where flight_phase='Landing'and class='incident' group by aircraft_type,plane_model,injury_level order by count(deaths) desc;
