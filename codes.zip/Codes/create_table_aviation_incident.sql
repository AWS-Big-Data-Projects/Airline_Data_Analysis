CREATE TABLE IF NOT EXISTS aviation_inciedent(
`incident_occured_date` VARCHAR(50), 
`aircraft_type` VARCHAR(50),
`airline_operator` VARCHAR(50),
`class` VARCHAR(50),
`deaths` BIGINT(10),
`flight_phase` VARCHAR(50),
`injury_level` VARCHAR(50),
`is_it_airplane` VARCHAR(50),
`is_it_helicopter` VARCHAR(50),
`list_of_occurrence_categery` VARCHAR(50),
`location` VARCHAR(50),
`plane_model` VARCHAR(50),
`plane_register_no` VARCHAR(50),
`state_of_occurrence` VARCHAR(50),
`state_of_registry_code` VARCHAR(50),
`year` VARCHAR(50)
);
